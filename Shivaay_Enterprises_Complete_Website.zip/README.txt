SHIVAAY ENTERPRISES WEBSITE
Upload ONLY index.html to your GitHub repository.

Categories included:
Ladoo Gopal Shringar; Ladoo Gopal Dresses & Accessories; Kitchen Accessories;
Children Toys; Moringa Powder & Moringa Leaves; Pooja Needs; Pooja Samagri.

Every product card has Name, Category, SKU, Rating and Price fields.
Price is blank for now. Replace the emoji placeholders with real product photos later.
